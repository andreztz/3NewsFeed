digger = False

custom_interval = 1

#browser_cmd = "konqueror %s &"

#config_file = "/Users/martin/Public/testfile"

fontscaling = 1.2

ask_before_deletion = False
