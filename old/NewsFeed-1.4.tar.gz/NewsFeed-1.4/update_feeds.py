#!/usr/bin/env python

from newsfeed import *

debug = 0

try:
	pid = open(pid_file, 'r').read()
	sys.stderr.write("NewsFeed is currently running under PID %s, aborting update.\n" % pid)
except:
	print "updating feeds..."

	newsfeeds, config = cPickle.load(open(config_file, 'r'))

	for f in [x for x in newsfeeds if not isinstance(x, SearchWire)]:
		f.u_time = approx_time()

	for f in [x for x in newsfeeds if not isinstance(x, SearchWire)]:
		if debug: print f.name
		f.get_news(refresh = 1)

	for fs in [x for x in newsfeeds if isinstance(x, SearchWire)]:
		fs.get_news(refresh = 1)

	try: cPickle.dump((newsfeeds, config), open(config_file, 'w'), 1)
	except:
		sys.stderr.write("Error: Writing cache file failed.\n")
		sys.exit(2)
