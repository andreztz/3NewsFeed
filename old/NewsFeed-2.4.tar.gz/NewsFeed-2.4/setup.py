#!/usr/bin/env python

from distutils.core import setup

setup(name="NewsFeed",
        version="2.4",
        description="A reader and aggregator for RSS/RDF/Atom feeds in Python/Tk",
        author="Martin C. Doege",
        author_email="mdoege@compuserve.com",
	url="http://thor.prohosting.com/~mdoege/newsfeed/",
        py_modules=["newsfeed", "rssfinder", "rssparser", "timeoutsocket"],
	scripts=["newsfeed", "add_feed.py", "feed2opml.py", "opml2feed.py", "dumpfeed.py", "update_feeds.py", "dinos.py"],
	data_files=[('/usr/X11R6/share/gnome/sounds', ['email.wav'])] )
