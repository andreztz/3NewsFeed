#!/usr/bin/env python

"""
A Python/Tk RSS/RDF/Atom news aggregator. See included README.html for documentation.

Martin Doege, 2006-01-26

"""

# This script is the same as "newsfeed" and is only provided because Windows requires a ".py"
# extension for starting a Python script in the GUI. Unix users will probably use "newsfeed"
# to launch the program.

import sys

assert sys.version >= '2.2', "This program has not been tested with older versions of Python. Please install Python 2.2 or greater."

from newsfeed import *

if __name__ == '__main__':
	try: main()
	finally:
		try: os.unlink(pid_file)
		except: pass
		save()
