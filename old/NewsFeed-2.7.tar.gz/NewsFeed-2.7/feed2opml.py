#!/usr/bin/env python

# 2006-01-26

# Dump NewsFeed database as an OPML file.

# Usage: ./feed2opml.py > myfeeds.opml


from newsfeed import ContentItem, NewsWire, SearchWire, config_file, console_encoding

import os, string, cPickle

newfeeds = []
config   = {}

newsfeeds, config = cPickle.load(open(config_file, 'rb'))
enc = console_encoding

print '<?xml version="1.0" encoding="%s"?>' % enc
print '<opml version="1.0">\n<head><title>NewsFeed Bookmarks</title></head>\n<body>'

def mkfile(t):
	t = string.replace(t, " ", "").lower()[0:16]
	t = string.replace(t, ",", "_")
	t = string.replace(t, ".", "_")
	return t

for f, i in zip(newsfeeds, range(len(newsfeeds))):
	if not isinstance(f, SearchWire):
		title = string.replace(f.name, '"', '\\"')
		if type(title) == type(u""): title = title.encode(enc, "replace")
		name = f.name
		if type(name) == type(u""): name = name.encode(enc, "replace")		
		url = string.replace(f.url, '&', '&amp;')
		homeurl = string.replace(f.homeurl, '&', '&amp;')
		print '<outline text="%s" title="%s" xmlUrl="%s" htmlUrl="%s" filename="%s%04u.xml" />' % (
			title, title, url, homeurl, mkfile(name), i + 1)

print '</body></opml>'
