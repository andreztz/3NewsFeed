#!/usr/bin/env python

# 2007-08-23

# Print the number of bytes occupied by the contents of each feed

# Usage: bsize [minimum size in bytes]

from newsfeed import NewsWire, SearchWire, config_file, console_encoding

import sys, time, cPickle

try:    min_size = int(sys.argv[1])
except: min_size = 10000		# default minimum size reported


def comp(x, y):
	"Compare two items by time."
	if x[1] - y[1] < 0: return 1
	else: return -1


newsfeeds, config = cPickle.load(open(config_file, 'rb'))

res = []

for f in newsfeeds:
	if not isinstance(f, SearchWire):
		name = f.name
		if type(name) == type(u""):
			name = name.encode(console_encoding, 'replace')
		size = 0
		for n in f.content:
			size += len(n.title) + len(n.descr)
		res.append( [name, size] )

res.sort(comp)

print
print "%30s  |  %s" % ("Feed name", "Size (bytes)")
print 74 * '='

for x, y in res:
	if y > min_size: print "%30s  |  %u" % (x[:30], int(y))

print
