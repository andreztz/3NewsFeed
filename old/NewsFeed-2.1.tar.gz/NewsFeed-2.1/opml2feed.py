#!/usr/bin/env python

# 2004-11-10

from newsfeed import ContentItem, NewsWire, SearchWire, config_file

import os, sys, string, cPickle, fileinput, xml.sax

from xml.sax.handler import *

newsfeeds = []
config    = {}
num   = 0
total = 0

newsfeeds, config = cPickle.load(open(config_file, 'rb'))

class OPMLHandler(ContentHandler):
	def startElement(s, n, a):
		global newsfeeds, urls, num, total

		total += 1
		name = string.replace(a.get('title') or a.get('text', "?"), '\\"', '"')
		url  = a.get('xmlurl') or a.get('xmlUrl') or a.get('url', "http://")
		homeurl = a.get('htmlurl') or a.get('htmlUrl') or "http://"

		if url not in urls or url == "http://":
			newsfeeds.append(NewsWire(name = name, url  = url, homeurl = homeurl,
				refresh = config['refresh_every'], expire = config['maxtime']))
			num += 1

newsfeeds = [x for x in newsfeeds if not isinstance(x, SearchWire)]
urls = []
for x in newsfeeds: urls += [x.url]

h = OPMLHandler()
if len(sys.argv) < 2:
	sys.stderr.write("Please supply a filename on the commandline.\n")
	sys.exit(1)
xml.sax.parse(sys.argv[1], h)

print "Added %u new feeds from a total of %u." % (num, total)

cPickle.dump((newsfeeds, config), open(config_file, 'wb'), 1)
