#!/usr/bin/env python

# 2005-01-31

from newsfeed import ContentItem, NewsWire, SearchWire, config_file

import os, string, cPickle

newfeeds = []
config   = {}

newsfeeds, config = cPickle.load(open(config_file, 'rb'))

print '<?xml version="1.0" encoding="ISO-8859-1"?>'
print '<opml version="1.0">\n<head><title>NewsFeed Bookmarks</title></head>\n<body>'

def mkfile(t):
	t = string.replace(t, " ", "").lower()[0:16]
	t = string.replace(t, ",", "_")
	t = string.replace(t, ".", "_")
	return t

for f, i in zip(newsfeeds, range(len(newsfeeds))):
	if not isinstance(f, SearchWire):
		title = string.replace(f.name, '"', '\\"')
		if type(title) == type(u""): title = title.encode("latin-1", "replace")
		name = f.name
		if type(name) == type(u""): name = name.encode("latin-1", "replace")		
		url = string.replace(f.url, '&', '&amp;')
		homeurl = string.replace(f.homeurl, '&', '&amp;')
		print '<outline text="%s" title="%s" xmlUrl="%s" htmlUrl="%s" filename="%s%04u.xml" />' % (
			title, title, url, homeurl, mkfile(name), i + 1)

print '</body></opml>'
