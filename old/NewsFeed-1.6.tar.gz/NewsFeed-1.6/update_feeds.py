#!/usr/bin/env python

# 2004-08-12

from newsfeed import *


try:
	pid = open(pid_file, 'r').read()
	if len(sys.argv) == 2 and sys.argv[1] == '-v':
		print "NewsFeed is currently running under PID %s, aborting update.\n" % pid
except:
	newsfeeds, config = cPickle.load(open(config_file, 'r'))

	for f in [x for x in newsfeeds if not isinstance(x, SearchWire)]:
		f.u_time = approx_time()

	for f in [x for x in newsfeeds if not isinstance(x, SearchWire)]:
		f.get_news(refresh = 1)

	for fs in [x for x in newsfeeds if isinstance(x, SearchWire)]:
		fs.get_news(refresh = 1)

	try: cPickle.dump((newsfeeds, config), open(config_file, 'w'), 1)
	except:
		sys.stderr.write("Error: Writing cache file failed.\n")
		sys.exit(2)
