#!/usr/bin/env python

"""
A Python/Tk RSS/RDF/Atom news aggregator. See included README.html for documentation.

Martin Doege, 2004-02-20

"""

import sys

assert sys.version >= '2.2', "This program has not been tested with older versions of Python. Please install Python 2.2 or greater."

from newsfeed import *

if __name__ == '__main__':
	try: main()
	finally:
		try: os.unlink(pid_file)
		except: pass
		save()
